using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Game Settings")]
    public int totalDays = 3;
    public int totalNPCs = 3;

    [Header("Current Day")]
    public int currentDay = 1;

    //choices for the day [day][npc]
    private PlayChoice[,] choices;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        DontDestroyOnLoad(gameObject);

        choices = new PlayChoice[totalDays, totalNPCs];
    }

    //records player choice
    public void RecordChoice(int npcID, PlayChoice choice)
    {
        int dayIndex = currentDay - 1;

        if (npcID < 0 || npcID >= totalNPCs)
        {
            Debug.LogError("Invaild NPC ID: " + npcID);
            return;
        }

        choices[dayIndex, npcID] = choice;

        Debug.Log("Day " + currentDay + " | NPC " + npcID + " | Choice: " + choice);
    }

    public PlayChoice GetChoice(int day, int npcID)
    {
        return choices[day - 1, npcID];
    }

    // check whether every npc has been talked too

    public bool HaveAllNPCsBeenSpokenTo()
    {
        int dayIndex = currentDay - 1;

        NPCController[] npcs = FindObjectsByType<NPCController>(FindObjectsSortMode.None);

        Debug.Log("Checking end of day npcs found: " + npcs.Length);

        //foreach (int npc = 0; npc < totalNPCs; npc++)
        foreach(NPCController npc in npcs)
        {

            //dead npcs count as completed
            if (npc.IsDead())
            {
                Debug.Log(npc.npcName + " is dead. is completed");
                continue;
            }

            Debug.Log(npc.npcName + " | Spoken today: " + npc.spokenToToday);

            //living npc must have been spoken too.
            if (!npc.spokenToToday)
            {
                Debug.Log("Day cannot end. still need to talk to: " + npc.npcName);
                return false;

            }
                
            /*
            if (choices[dayIndex, npc] == PlayChoice.None)
            {
                return false;
            }
            */
        }
        Debug.Log("All living NPCs have been spoken to!");
        return true;
    }

    // move to the next day
    public void NextDay()
    {
        if (currentDay >= totalDays)
        {
            Debug.Log("Three days are complete");

            EndingManager.Instance.DetermineEnding();
            return;
        }

        currentDay++;

        Debug.Log("Day " + currentDay);

        ResetNPCInteractions();
    }

    void ResetNPCInteractions()
    {
        NPCController[] npcs = FindObjectsByType<NPCController>(FindObjectsSortMode.None);

        foreach (NPCController npc in npcs)
        {
            npc.ResetDailyInteration();
        }
    
    }

    // check whether every npc has ever been killed
    public bool HasKilledEveryone()
    {
        for (int npc = 0; npc < totalNPCs; npc++)
        {
            bool killed = false;

            for(int day = 0; day < totalDays; day++)
            {
                if (choices[day, npc] == PlayChoice.Kill)
                {
                    killed = true;
                    break;
                }
            }
            if(!killed)
            {
                return false;
            }
        }

        return true;
    }

    // check whether every choice over all 3 days was the same
    public bool AllChoicesAre(PlayChoice desiredChoice)
    {
        for (int day = 0; day < totalDays; day++)
        {
            for (int npc = 0; npc < totalNPCs; npc++)
            {
                if (choices[day, npc] != desiredChoice)
                {
                    return false;
                }
            }
           
        }

        return true;
    }

    public bool WasNPCKilled(int npcID)
    {
        for(int day = 0; day < totalDays; day++)
        {
            if (choices[day, npcID] == PlayChoice.Kill)
            {
                return true;
            }
        }
        return false;
    }
    
}
