using UnityEngine;
using UnityEngine.UI;
using TMPro;
//using JetBrains.Annotations;
//using Unity.Multiplayer.Center.Common;

public class DialogueManager : MonoBehaviour
{

    public static DialogueManager Instance;

    [Header("Dialogue UI")]
    public GameObject dialoguePanel;

    public TMP_Text npcNameText;
    public TMP_Text dialogueText;

    [Header("Choice Buttons")]
    public Button loveButton;
    public Button hurtButton;
    public Button leaveButton;
    public Button killButton;

    private NPCController currentNPC;

    private void Awake()
    {
        Instance = this;
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        dialoguePanel.SetActive(false);

        loveButton.onClick.AddListener(ChooseLove);
        hurtButton.onClick.AddListener(ChooseHurt);
        leaveButton.onClick.AddListener(ChooseLeave);
        killButton.onClick.AddListener(ChooseKill); 

    }

    public void StartDialogue(NPCController npc)
    {
        if(npc.spokenToToday)
        {
            Debug.Log(npc.npcName + " has already been spoken to today.");
            return;
        }

        currentNPC = npc;

        dialoguePanel.SetActive(true);

        npcNameText.text = npc.npcName;
        dialogueText.text = npc.greeting;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void ChooseLove()
    {
        MakeChoice(PlayChoice.Love);
    }

    void ChooseHurt()
    {
        MakeChoice(PlayChoice.Hurt);
    }

    void ChooseLeave()
    {
        MakeChoice(PlayChoice.Leave);
    }

    void ChooseKill()
    {
        MakeChoice(PlayChoice.Kill);
    }

    void MakeChoice(PlayChoice choice)
    {
        if (currentNPC == null)
            return;

        Debug.Log("Player chose " + choice + " with " + currentNPC.npcName);

        //records the choices
        GameManager.Instance.RecordChoice(currentNPC.npcID, choice);

        if(choice == PlayChoice.Kill)
        {
            NPCFate Fate = currentNPC.GetComponent<NPCFate>();

            if(Fate != null)
            {
                Fate.Kill();
            }
        }

        // mark this npc as spoken too today
        currentNPC.spokenToToday = true;

        // close dialogue
        EndDialogue();

        DayManager.Instance.CheckForEndOfDay();
    }

    public void EndDialogue()
    {
        currentNPC = null;

        dialoguePanel.SetActive(false);

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

 
}
