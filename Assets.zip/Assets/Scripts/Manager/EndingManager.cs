using UnityEngine;
using UnityEngine.SceneManagement;

public class EndingManager : MonoBehaviour
{
    public static EndingManager Instance;

    [Header("Ending Scenes")]
    public string goodEndingScene = "GoodEnding";
    public string exiledEndingScene = "ExiledEnding";
    public string forgottenEndingScene = "ForgottenEnding";
    public string ghostTownEndingScene = "GhostTownEnding";// might change this ending name to "The True Monster" later
    public string strangerEndingScene = "Strangerending"; // might change this name "Stranger with no name ending"

    public void Awake()
    {
        if(Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        DontDestroyOnLoad(gameObject);
    }

    public void DetermineEnding()
    {
        if(GameManager.Instance.HasKilledEveryone())
        {
            Debug.Log("END: The True Monster...");

            LoadEnding(ghostTownEndingScene);
            return;
        }

        if(GameManager.Instance.AllChoicesAre(PlayChoice.Love))
        {
            Debug.Log("ENDING: Town Hero");

            LoadEnding(goodEndingScene);
            return;
        }

        if(GameManager.Instance.AllChoicesAre(PlayChoice.Hurt))
        {
            Debug.Log("ENDING: EXIlED");

            LoadEnding(exiledEndingScene);
            return;
        }

        if(GameManager.Instance.AllChoicesAre(PlayChoice.Leave))
        {
            Debug.Log("ENDING: Forgotten Forever...");

            LoadEnding(forgottenEndingScene);
            return;
        }

        Debug.Log("ENDING: Stranger With no Name"); // the normal ending
        LoadEnding(strangerEndingScene);
    }
    
    void LoadEnding(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
}
