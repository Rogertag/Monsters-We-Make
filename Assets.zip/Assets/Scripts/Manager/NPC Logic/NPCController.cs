using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class NPCController : MonoBehaviour
{
    [Header("NPC Information")]
    public int npcID;
    public string npcName = "NPC";
    private NPCFate npcFate;

    [TextArea(2, 5)] // base greeting on interaction
    public string greeting = "Hello, stranger.";

    [Header("Movement")]
    [SerializeField] private bool canMove = true;
    [SerializeField] private float moveSpeed = 2f;
    //[SerializeField] private float wanderRadius = 3f;
    [SerializeField] private float waitTime = 2f;

    [Header("Wander Area")]
    [SerializeField] private BoxCollider2D wanderArea;
    [SerializeField] private float stoppingDistance = 0.05f;

    [Header("Interacion")]
    // has this npc been spoken to for the day?
    public bool spokenToToday = false;

    private Rigidbody2D rb;

    private Vector2 homePosition;
    private Vector2 targetPosition;

    private float waitTimer;
    private bool moving;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        npcFate = GetComponent<NPCFate>();// subject to change
    }



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        homePosition = transform.position;
        targetPosition = transform.position;

        ChooseNewDestination();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!canMove || IsDead())
            return;

        if (!moving)
        {
            waitTimer -= Time.deltaTime;

            if(waitTimer <= 0f)
            {
                ChooseNewDestination();
            }
        }
    }

    private void FixedUpdate()
    {
        if (!canMove || !moving || IsDead())
            return;

        Vector2 currentPosition = rb.position;

        Vector2 newPosition = Vector2.MoveTowards(currentPosition, targetPosition, moveSpeed * Time.fixedDeltaTime);

        rb.MovePosition(newPosition);

        if (Vector2.Distance(newPosition, targetPosition) <= stoppingDistance)
        {
            moving = false;
            waitTimer = waitTime;
        }
    }

    private void ChooseNewDestination()
    {
        if(wanderArea == null)
        {
            Debug.LogWarning(npcName + " does not have a wander area. ");
            return;
        }

        Bounds bounds = wanderArea.bounds;

        float randomX = Random.Range(bounds.min.x, bounds.max.x);
        float randomY = Random.Range(bounds.min.y, bounds.max.y);

        targetPosition = new Vector2(randomX, randomY);

       // Vector2 randomOffset = Random.insideUnitCircle * wanderRadius;

       // targetPosition = homePosition + randomOffset;

        moving = true;
    }

    public void SetCanMove(bool value)
    {
        canMove = value;

        if (!canMove)
        {
            moving = false;
        }
    }
    
    public void SetTargetPosition(Vector3 newPosition)
    {
        targetPosition = newPosition;
    }

    public void ResetDailyInteration()
    {
        spokenToToday = false;
    }

    public bool IsDead()
    {
        return npcFate != null && npcFate.IsDead;
    }
}
