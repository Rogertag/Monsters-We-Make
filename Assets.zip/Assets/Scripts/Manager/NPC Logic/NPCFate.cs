using UnityEngine;


public enum NPCState
{
    Alive,
    Dead
}

public class NPCFate : MonoBehaviour
{

    [Header("Current Fate")]
    [SerializeField] private NPCState currentState = NPCState.Alive;

    [Header("Visuals")]
    [SerializeField] private GameObject aliveVisual;
    [SerializeField] private GameObject deadVisual;

    private NPCController npcController;
    public bool IsDead => currentState == NPCState.Dead;
    public bool IsAlive => currentState == NPCState.Alive;

    private void Awake()
    {
        npcController = GetComponent<NPCController>();
    }

    private void Start()
    {
        UpdateVisuals();
    }

    public void Kill()
    {
        if (IsDead)
            return;

        currentState = NPCState.Dead;

        if (npcController != null)
            npcController.SetCanMove(false);

        UpdateVisuals();

        Debug.Log(gameObject.name + " has died.");
    }

    public void Revive()
    {
        currentState = NPCState.Alive;
    }

    private void UpdateVisuals()
    {
        if (aliveVisual != null)
            aliveVisual.SetActive(IsAlive);

        if(deadVisual != null)
            deadVisual.SetActive(IsDead);
    }
   
}
