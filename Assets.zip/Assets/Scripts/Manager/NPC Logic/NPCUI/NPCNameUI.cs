using UnityEngine;
using TMPro;

public class NPCNameUI : MonoBehaviour
{

    [SerializeField] private NPCController npc;
    [SerializeField] private TMP_Text nameText;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (npc == null)
            npc = GetComponentInParent<NPCController>();

        UpdateName();

       // if(npc != null && nameText != null )
       // {
      //      nameText.text = npc.npcName;
      //  }
    }

    private void Update()
    {
        if (npc == null)
            return;

        UpdateName();
    }

    private void UpdateName()
    {
        if(npc.spokenToToday)
        {
            nameText.text = "Done Talking " + npc.npcName;
            nameText.color = Color.green;
        }
        else
        {
            nameText.text = npc.npcName;
            nameText.color = Color.white;
        }
    }


}
