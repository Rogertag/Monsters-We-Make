using UnityEngine;
using TMPro;

public class NPCInteractionUI : MonoBehaviour
{
    [SerializeField] private GameObject prompt;


    public void ShowPrompt()
    {
        prompt.SetActive(true);
    }

    public void HIdePrompt()
    {
        prompt.SetActive(false);
    }
}
