using UnityEngine;
using TMPro;
//using UnityEditor.ShaderGraph.Internal;

public class DayManager : MonoBehaviour
{
    public static DayManager Instance;

    [Header("Day Settings")]
    public float delayBeforeNextDay = 2f;

   // private bool changingDay = false;

    [Header("Day Settings")]
    [SerializeField] private GameObject goToBedButton;
    [SerializeField] private TMP_Text dayText;

    [Header("Day Introduction")]
    [SerializeField] private GameObject dayIntroPanel;
    [SerializeField] private TMP_Text dayIntroText;
    [SerializeField] private float dayIntroDuration = 2f;

    private void Awake()
    {
        if(Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        UpdateDayUI();

        if (goToBedButton != null)
            goToBedButton.SetActive(false);

        if (dayIntroPanel != null)
            dayIntroPanel.SetActive(false);

        ShowDayIntroduction();
    }

    public void CheckForEndOfDay()
    {
       // if (changingDay)
        //    return;

        if(GameManager.Instance.HaveAllNPCsBeenSpokenTo())
        {
            /*
            changingDay = true;

            Debug.Log("Everyone has been spoken to. Ending Day " + GameManager.Instance.currentDay);

            Invoke(nameof(StartNextDay), delayBeforeNextDay);
            */

            Debug.Log("Everyone has been spoken to.");

            if (goToBedButton != null)
                goToBedButton.SetActive(true);

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    public void ShowDayIntroduction() // work on this later
    {
        if (dayIntroPanel == null || dayIntroText == null)
            return;

        dayIntroText.text = "Day " + GameManager.Instance.currentDay;
       // dayIntroPanel.SetActive
    }

    public void GoToBed()
    {
        if(!GameManager.Instance.HaveAllNPCsBeenSpokenTo())
        {
            Debug.Log("There are still people to talk to");
            return;
        }

        Debug.Log("Going to bed");

        if (goToBedButton != null)
            goToBedButton.SetActive(false);

        // lock and hide the cursor again
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        GameManager.Instance.NextDay();

        UpdateDayUI();
    }

    private void UpdateDayUI()
    {
        if(dayText != null)
        {
            dayText.text = "Day " + GameManager.Instance.currentDay;
        }
    }

    /*
    void StartNextDay()
    {
        changingDay = false;

        GameManager.Instance.NextDay();
    }
    */
   
}
