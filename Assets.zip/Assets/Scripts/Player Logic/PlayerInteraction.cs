using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    [Header("Interaction")]
    [SerializeField] private float interactionDistance = 1.5f;
    [SerializeField] private LayerMask npcLayer;

    private NPCController nearbyNPC;
    private NPCController previousNPC;

    

    // Update is called once per frame
    void Update()
    {
        /*
        if(DialogueManager.Instance != null)
        {
            if(Input.GetKeyDown(KeyCode.E))
            {
                //Dialogue manager handles whether dialogue is open.
            }
        }
        */

        FindNearbyNPC();

        if(nearbyNPC != null && Input.GetKeyDown(KeyCode.E))
        {
            StartConversation();
        }
        
    }

    void FindNearbyNPC()
    {
        Collider2D[] objects = Physics2D.OverlapCircleAll(transform.position, interactionDistance, npcLayer);

        nearbyNPC = null;

        float closestDistance = Mathf.Infinity;

        foreach (Collider2D obj in objects)
        {
            NPCController npc = obj.GetComponent<NPCController>();

            if (npc == null)
                continue;

            // no interaction with npc because they are dead
            if (npc.IsDead())
                continue;
            
                float distance = Vector2.Distance(transform.position, npc.transform.position);

                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    nearbyNPC = npc;
                    
                }
            
        }
        UpdateInterationPrompt();
    }

    private void UpdateInterationPrompt()
    {
        // hides the previous npc prompt
        if(previousNPC != null && previousNPC != nearbyNPC)
        {
            NPCInteractionUI previousUI = previousNPC.GetComponentInChildren<NPCInteractionUI>();

            if (previousUI != null)
                previousUI.HIdePrompt();
        }

        // show new npc prompt
        if(nearbyNPC != null)
        {
            NPCInteractionUI currentUI = nearbyNPC.GetComponentInChildren<NPCInteractionUI>();

            if (currentUI != null)
                currentUI.ShowPrompt();
        }

        previousNPC = nearbyNPC;
    }

    void StartConversation()
    {
        if (nearbyNPC == null)
            return;

        if (nearbyNPC.IsDead())
            return;

        Debug.Log("Talking to " + nearbyNPC.npcName);

        if(DialogueManager.Instance != null)
        {
            nearbyNPC.SetCanMove(false);

            DialogueManager.Instance.StartDialogue(nearbyNPC);
        }
        else
        {
            Debug.LogError("DialogueManager Instance not found");
        }

        
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, interactionDistance);
    }
}
