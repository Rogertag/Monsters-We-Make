using UnityEngine;

public enum PlayChoice
{
    None,
    Love,
    Hurt,
    Leave,
    Kill
}
